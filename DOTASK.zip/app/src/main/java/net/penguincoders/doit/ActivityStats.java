package net.penguincoders.doit;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
public class ActivityStats extends AppCompatActivity
{
    public int inta = 0, creat = 0, str = 0, sta = 0, intaG = 1, creatG = 1, staG = 1, strG = 1;
    public int intak = 100, creak = 100, strk = 100, stak = 100;
    private ProgressBar prbint;
    private ProgressBar prbcrt;
    private ProgressBar prbsta;
    private ProgressBar prbstr;
    private TextView txtinta;
    private TextView txtcrt;
    private TextView txtsta;
    private TextView txtstr;
    private TextView daytest;
    ImageButton button;
    SharedPreferences sPref;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        prbint = findViewById(R.id.pbr_int);
        prbcrt = findViewById(R.id.prb_crt);
        prbsta = findViewById(R.id.prb_sta);
        prbstr = findViewById(R.id.prb_str);
        txtinta=findViewById(R.id.inta1);
        txtinta.setText(String.valueOf(intaG));
        txtcrt=findViewById(R.id.crt);
        txtcrt.setText(String.valueOf(creatG));
        txtsta=findViewById(R.id.sta);
        txtsta.setText(String.valueOf(staG));
        txtstr=findViewById(R.id.str);
        txtstr.setText(String.valueOf(strG));


load();
        prbint.setProgress(inta);
        prbstr.setProgress(str);
        prbsta.setProgress(sta);
        prbcrt.setProgress(creat);
        prbint.setMax(intak);
        prbsta.setMax(stak);
        prbstr.setMax(strk);
        prbcrt.setMax(creak);
        txtinta.setText(String.valueOf(intaG));
        txtstr.setText(String.valueOf(strG));
        txtsta.setText(String.valueOf(staG));
        txtcrt.setText(String.valueOf(creatG));
    }
    public void seve()
    {
        sPref = getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences.Editor ed = sPref.edit();
        ed.putInt("inta",inta);
        ed.putInt("creat",creat);
        ed.putInt("str",str);
        ed.putInt("sta",sta);

        ed.putInt("intaG",intaG);
        ed.putInt("creatG",creatG);
        ed.putInt("strG",strG);
        ed.putInt("staG",staG);
        ed.putInt("intak",intak);
        ed.putInt("creak",creak);
        ed.putInt("strk",strk);
        ed.putInt("stak",stak);
        ed.putInt("intak",intak);

        ed.commit();
    }
    public  void load()
    {
        sPref = getSharedPreferences("MyPref", MODE_PRIVATE);
        inta = sPref.getInt("inta",0);
        creat = sPref.getInt("creat",0);
        sta = sPref.getInt("sta",0);
        str = sPref.getInt("str",0);
        intaG = sPref.getInt("intaG",0);
        creatG = sPref.getInt("creatG",0);
        staG = sPref.getInt("staG",0);
        strG = sPref.getInt("strG",0);
        intak = sPref.getInt("intak",0);
        creak = sPref.getInt("creak",0);
        stak = sPref.getInt("stak",0);
        strk = sPref.getInt("strk",0);


    }



    public void read(View v) {

        inta += 10;
        if (inta > intak) {
            intaG += 1;
            inta=0;
            txtinta.setText(String.valueOf(intaG));

            intak += 30;
            prbint.setMax(intak);
        }

        prbint.setProgress(inta);
        button=findViewById(R.id.stud);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));

    }
    public void com(View v) {

        inta += 10;
        creat+=5;
        if (inta > intak) {
            intaG += 1;
            inta=0;
            txtinta.setText(String.valueOf(intaG));

            intak += 30;
            prbint.setMax(intak);
        }
        if (creat > creak) {
            creatG += 1;
            creat=0;
            txtcrt.setText(String.valueOf(creatG));

            creak += 30;
            prbcrt.setMax(creak);
        }

        prbint.setProgress(inta);
        prbcrt.setProgress(creat);
        button=findViewById(R.id.com);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));
    }
    public void vel(View v) {

        sta += 10;
        if (sta> stak) {
            staG+= 1;
            sta=0;
            txtsta.setText(String.valueOf(staG));

            stak += 30;
            prbsta.setMax(stak);
        }

        prbsta.setProgress(sta);
        button=findViewById(R.id.vel);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));

    }
    public void beg(View v) {

        sta += 15;
        str+=5;
        if (sta > stak) {
            staG+= 1;
            sta=0;
            txtsta.setText(String.valueOf(staG));

            stak += 30;
            prbsta.setMax(stak);
        }
        if (str > strk) {
            strG += 1;
            str=0;
            txtstr.setText(String.valueOf(strG));

            strk += 30;
            prbstr.setMax(strk);
        }

        prbstr.setProgress(str);
        prbsta.setProgress(sta);
        button=findViewById(R.id.beg);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));
    }
    public void rab(View v) {

        sta += 10;
        str+=15;
        if (sta > stak) {
            staG+= 1;
            sta=0;
            txtsta.setText(String.valueOf(staG));

            stak += 30;
            prbsta.setMax(stak);
        }
        if (str > strk) {
            strG += 1;
            str=0;
            txtstr.setText(String.valueOf(strG));

            strk += 30;
            prbstr.setMax(strk);
        }

        prbstr.setProgress(str);
        prbsta.setProgress(sta);
        button=findViewById(R.id.wor);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));

    }
    public void box(View v) {

        sta += 5;
        str+=10;
        if (sta > stak) {
            staG+= 1;
            sta=0;
            txtsta.setText(String.valueOf(staG));

            stak += 30;
            prbsta.setMax(stak);
        }
        if (str > strk) {
            strG += 1;
            str=0;
            txtstr.setText(String.valueOf(strG));

            strk += 30;
            prbstr.setMax(strk);
        }

        prbstr.setProgress(str);
        prbsta.setProgress(sta);
        button=findViewById(R.id.kar);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));

    }
    public void is(View v) {

        inta += 5;
        creat+=10;
        if (inta > intak) {
            intaG += 1;
            inta=0;
            txtinta.setText(String.valueOf(intaG));

            intak += 30;
            prbint.setMax(intak);
        }
        if (creat > creak) {
            creatG += 1;
            creat=0;
            txtcrt.setText(String.valueOf(creatG));

            creak += 30;
            prbcrt.setMax(creak);
        }

        prbint.setProgress(inta);
        prbcrt.setProgress(creat);
        button=findViewById(R.id.is);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));

    }
    public void re(View v) {

        inta += 20;
        creat += 10;
        if (inta > intak) {
            intaG += 1;
            inta = 0;
            txtinta.setText(String.valueOf(intaG));

            intak += 30;
            prbint.setMax(intak);
        }
        if (creat > creak) {
            creatG += 1;
            creat = 0;
            txtcrt.setText(String.valueOf(creatG));

            creak += 30;
            prbcrt.setMax(creak);
        }

        prbint.setProgress(inta);
        prbcrt.setProgress(creat);
        button=findViewById(R.id.riad);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));
    }
    public void ris(View v) {

        inta += 5;
        creat += 20;
        if (inta > intak) {
            intaG += 1;
            inta = 0;
            txtinta.setText(String.valueOf(intaG));

            intak += 30;
            prbint.setMax(intak);
        }
        if (creat > creak) {
            creatG += 1;
            creat = 0;
            txtcrt.setText(String.valueOf(creatG));

            creak += 30;
            prbcrt.setMax(creak);
        }

        prbint.setProgress(inta);
        prbcrt.setProgress(creat);
        button=findViewById(R.id.ris);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));
    }
    public void plav(View v) {

        sta += 20;
        str+=10;
        if (sta > stak) {
            staG+= 1;
            sta=0;
            txtsta.setText(String.valueOf(staG));

            stak += 30;
            prbsta.setMax(stak);
        }
        if (str > strk) {
            strG += 1;
            str=0;
            txtstr.setText(String.valueOf(strG));

            strk += 30;
            prbstr.setMax(strk);
        }

        prbstr.setProgress(str);
        prbsta.setProgress(sta);
        button=findViewById(R.id.plaw);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));

    }
    public void srih(View v) {

        inta += 10;
        creat += 10;
        if (inta > intak) {
            intaG += 1;
            inta = 0;
            txtinta.setText(String.valueOf(intaG));

            intak += 30;
            prbint.setMax(intak);
        }
        if (creat > creak) {
            creatG += 1;
            creat = 0;
            txtcrt.setText(String.valueOf(creatG));

            creak += 30;
            prbcrt.setMax(creak);
        }

        prbint.setProgress(inta);
        prbcrt.setProgress(creat);
        button=findViewById(R.id.stih);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));
    }
    public void tren(View v) {

        str += 10;
        if (str > strk) {
            strG += 1;
            str=0;
            txtstr.setText(String.valueOf(strG));

            strk += 30;
            prbstr.setMax(strk);
        }

        prbstr.setProgress(str);
        button=findViewById(R.id.stan);
        button.setEnabled(false);
        button.setColorFilter(Color.argb(200, 255, 255, 255));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        seve();
    }
}


